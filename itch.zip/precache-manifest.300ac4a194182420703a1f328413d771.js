self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5de4733e44fb5b926a5a",
    "url": "/1.ff6acf5ba628effc9c16.js"
  },
  {
    "revision": "732ce03fc418df4910ae",
    "url": "/2.0aa5d089fe63201a6fa8.js"
  },
  {
    "revision": "ae9662e2c30c9563a92d508011bd83c2",
    "url": "/assets/ads.txt"
  },
  {
    "revision": "fec83330d41c4f4c915dae7f6a8220d6",
    "url": "/assets/android-chrome-192x192.png"
  },
  {
    "revision": "366424b29cdd7085fd8bbabc6a8c3b7e",
    "url": "/assets/android-chrome-256x256.png"
  },
  {
    "revision": "4b1042b5254bd54801ba1e08f576381e",
    "url": "/assets/apple-touch-icon-120x120.png"
  },
  {
    "revision": "f92d754288ab63ed7f4d57d61828f2ff",
    "url": "/assets/apple-touch-icon-152x152.png"
  },
  {
    "revision": "d37c95c2a2895151be72f6b70ea124b2",
    "url": "/assets/apple-touch-icon-180x180.png"
  },
  {
    "revision": "0c6fce5a532a3d886edd8fc751f6fcc2",
    "url": "/assets/apple-touch-icon-60x60.png"
  },
  {
    "revision": "b0f8318addac626ff4ebf4fb2749c112",
    "url": "/assets/apple-touch-icon-76x76.png"
  },
  {
    "revision": "d37c95c2a2895151be72f6b70ea124b2",
    "url": "/assets/apple-touch-icon.png"
  },
  {
    "revision": "a493ba0aa0b8ec8068d786d7248bb92c",
    "url": "/assets/browserconfig.xml"
  },
  {
    "revision": "8541fad56563eeb80148e26505bc1c07",
    "url": "/assets/favicon-16x16.png"
  },
  {
    "revision": "bc003177d3e0fa86787753c4ae8f6f5d",
    "url": "/assets/favicon-32x32.png"
  },
  {
    "revision": "395cf26201869d58ec7c42b2f31e40f8",
    "url": "/assets/favicon.ico"
  },
  {
    "revision": "3ed59c98ec041d25145e97a30e3e3a0c",
    "url": "/assets/html_code.html"
  },
  {
    "revision": "2245825a2bc86406252146161025a57b",
    "url": "/assets/mstile-150x150.png"
  },
  {
    "revision": "f743400f99c2693af1edf6931bc761e6",
    "url": "/assets/safari-pinned-tab.svg"
  },
  {
    "revision": "25fc626cd69629cb4e1cac4c9c7c8997",
    "url": "/assets/site.webmanifest"
  },
  {
    "revision": "732ce03fc418df4910ae",
    "url": "/f463695acf7787f8bedc.module.wasm"
  },
  {
    "revision": "5df87414b885909d673746a578ec2dbf",
    "url": "/index.html"
  },
  {
    "revision": "f199a13811c4a7f9cbef",
    "url": "/main.4c6d3e66cf7076c048bf.js"
  },
  {
    "revision": "57a6ddb9cc068885cd530d743b3abb0d",
    "url": "/manifest.json"
  },
  {
    "revision": "ada739553c826bd50c0b22f5f07b5fce",
    "url": "/styles.css"
  }
]);